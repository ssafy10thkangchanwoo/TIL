<template>
    <div>
        <h1>예금비교</h1>
    </div>
</template>
  
<script setup>

</script>
  
<style  scoped></style>