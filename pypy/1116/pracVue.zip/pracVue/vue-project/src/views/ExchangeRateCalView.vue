<template>
    <div>
        <h1>환율 계산기</h1>
    </div>
</template>
  
<script setup>

</script>
  
<style  scoped></style>