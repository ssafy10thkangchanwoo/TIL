<template>
    <div>
        <h1>게시판 디테일</h1>
    </div>
</template>
  
<script setup>

</script>
  
<style  scoped></style>