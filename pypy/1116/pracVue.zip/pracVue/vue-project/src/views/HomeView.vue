<template>
  <div>
    <h1>home</h1>
  </div>
</template>

<script setup>

</script>

<style scoped></style>